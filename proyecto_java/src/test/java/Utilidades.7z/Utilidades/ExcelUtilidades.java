package Utilidades;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * LIBRERÍA INTERNA EQUIPO AUTOMATIZACIÓN PARA PRUEBAS QA EN PERIFERIA IT GROUP.
 *
 * @AUTHOR PERIFERIA IT GROUP - AUTOMATION EQUIPMENT
 * @VERSION 2.0
 * @SINCE 24/02/2025
 */


public class ExcelUtilidades {
	
	private static XSSFSheet excelWSheet;
	private static XSSFWorkbook excelWBook;
	private static XSSFCell cell;
	
	public static Object[][]getTableArray(String filePath, String sheetName)throws Exception
    {
        String[][] tabArray = null;
        try
        {
            FileInputStream excelFile = new FileInputStream(filePath);
            //ACCESS THE REQUIRED TEST DATA SHEET
            excelWBook= new XSSFWorkbook(excelFile);
            excelWSheet= excelWBook.getSheet(sheetName);
            int startRow=1;
            int startCol=0;
            int ci, cj;
            int totalRows= excelWSheet.getLastRowNum();
            int totalCols= excelWSheet.getRow(0).getPhysicalNumberOfCells();
            tabArray = new String[totalRows][totalCols];
            ci=0;
            for(int i= startRow; i<= totalRows; i++, ci++)
            {
                cj= 0;
                for(int j = startCol; j<=totalCols -1; j++, cj++)
                {
                    tabArray[ci][cj] = getcellData(i, j);
//                    System.out.println(tabArray[ci][cj]);                
                }
            }
        }catch(IOException e)
        {
            System.out.println("Could not read the excel sheet");
            e.printStackTrace();
        }        
        return(tabArray);
    }
	
	
	public static String getcellData(int rowNum, int colNum)
    {
        cell = excelWSheet.getRow(rowNum).getCell(colNum);
        String cellData = "";
        if(cell.getCellType()==null)
        {
            return "";
        }
        else
        {
            try
            {
                cellData = cell.getStringCellValue();
            }
            catch(Exception e)
            {
                cellData= Double.toString(cell.getNumericCellValue()).split("\\. ")[0];
            }            
        }
        return cellData;
    }	
 }
