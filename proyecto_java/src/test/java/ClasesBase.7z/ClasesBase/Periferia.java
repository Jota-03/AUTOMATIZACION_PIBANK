package ClasesBase;

import com.epam.healenium.SelfHealingDriver;
import com.itextpdf.text.DocumentException;
import Utilidades.GenerarReportePdf;
import RunPruebas.RunPrincipalTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;
import static org.testng.Assert.assertEquals;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.twocaptcha.TwoCaptcha;
import com.twocaptcha.captcha.ReCaptcha;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//Nuevas Importaciones
import org.openqa.selenium.io.FileHandler;
import com.google.zxing.*;
import com.google.zxing.NotFoundException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

/**
 * LIBRERÍA INTERNA EQUIPO AUTOMATIZACIÓN PARA PRUEBAS QA EN PERIFERIA IT GROUP.
 *
 * @AUTHOR PERIFERIA IT GROUP - AUTOMATION EQUIPMENT
 * @VERSION 6.0
 * @SINCE 24/02/2025
 */

public class Periferia {

	private static Logger log = LogManager.getLogger(RunPrincipalTest.class.getName());
	protected static SelfHealingDriver driver;
	public static WebDriverWait wait;
	static boolean isPresent = false;
	static String _rutaCarpeta, _generarEvidencia;

	/**
	 * Constructor base
	 */
	public Periferia(String rutaEvidencia) {
		_rutaCarpeta = rutaEvidencia;
	}

	/**
	 * CONSTRUCTOR DE TESTCASE
	 */
	public static void Setter(String generarEvidencia) {
		_generarEvidencia = generarEvidencia;
	}

	/**
	 * Inicializa el driver segun el navegador requerido
	 *
	 * @param browserType String para indicar el navegador para el test
	 * @param x           inndica las coordinada horizontal de la pantalla
	 * @param y           inndica las coordinada v de la pantalla
	 * @return driver Controlador para automatizar la prueba
	 * @throws IOException
	 */
	public static SelfHealingDriver inicializarNavegadores(String browserType) {
		// CONFIGURACIONES PARA EL NAVEGADOR DE CHROME
		if (browserType.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "D:/driver/chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-dev-shm-usage");
			options.addArguments("--no-sandbox");
			// IGNORA ERRORES EN CERTIFICADO EN NAVEGADOR
			options.addArguments("--ignore-certificate-errors");
			WebDriver delegate = new ChromeDriver(options);
			driver = SelfHealingDriver.create(delegate);
			driver.manage().window().maximize(); 
			options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
		} else if (browserType.equalsIgnoreCase("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions options = new FirefoxOptions();
			options.addArguments("--disable-dev-shm-usage");
			options.addArguments("--no-sandbox");
			WebDriver delegate = new FirefoxDriver(options);
			driver = SelfHealingDriver.create(delegate);
			driver.manage().window().maximize(); 
		}
		return driver;
	}

	/**
	 * Realiza un clic al elemento seleccionado.
	 *
	 * @param locator Localizador del elemento a interactuar.
	 * @param steps   Texto que se utilizará en la evidencia, para describir la
	 *                accion realizada.
	 * @param tiempo  Los segundos de espera antes de tomar la captura de la
	 *                evidencia.
	 * @throws Exception Si no se puede localizar el elemento, o si ocurre un error
	 *                   al generar la evidencia.
	 */
	public static void click(By locator, String steps, int tiempo) throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {
				driver.findElement(locator).click();
				tiempoEspera(tiempo);
				captureScreen(steps);
				// INICIO DE LOG
				log.info("Se realiza accion click sobre el elemento:{}", locator);
			} catch (Exception e) {
				captureScreenError(locator, e.toString());
				log.error(e.toString());
				throw new InterruptedException();
			}
		} else {
			try {
				driver.findElement(locator).click();
				tiempoEspera(tiempo);
			} catch (Exception e) {
				captureScreenError(locator, e.toString());
				log.error(e.toString());
				throw new InterruptedException();
			}
		}
	}

	/**
	 * Borra el texto al elemento seleccionado.
	 * 
	 * @param locator Localizador del elemento a interactuar.
	 * @param steps   Texto que se utilizará en la evidencia, para describir la
	 *                accion realizada.
	 * @param tiempo  Los segundos de espera antes de tomar la captura de la
	 *                evidencia.
	 * @throws Exception Si no se puede localizar el elemento, o si ocurre un error
	 *                   al generar la evidencia.
	 */
	public static void borrar(By locator, String steps, int tiempo) throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {
				driver.findElement(locator).clear();
				tiempoEspera(tiempo);
				captureScreen(steps);
				log.info("Se borra el texto del elemento: {}", locator);				
			} catch (Exception e) {
				captureScreenError(locator, "NO FUE POSIBLE LOCALIZAR EL ELEMENTO: (" + locator + ") PARA BORRAR: "
						+ "\n" + "### ERROR COMPLETO: " + e.toString() + " ###");
				printConsole(e.toString());
				log.error(e.toString());
				throw new InterruptedException();
			}
		} else {
			try {
				driver.findElement(locator).clear();
				tiempoEspera(tiempo);
			} catch (Exception e) {
				printConsole(e.toString());
			}
		}
	}

	/**
	 * Envía texto a un elemento mediante un localizador y toma una captura de
	 * pantalla en caso de error, si la generación de evidencia está habilitada.
	 *
	 * @param inputText El texto a enviar al elemento.
	 * @param locator   Localizador del elemento a interactuar.
	 * @param steps     Texto que se utilizará en la evidencia, para describir la
	 *                  accion realizada.
	 * @param tiempo    Los segundos de espera antes de tomar la captura de la
	 *                  evidencia.
	 * @throws Exception Si no se puede localizar el elemento, o si ocurre un error
	 *                   al generar la evidencia.
	 */
	public static void sendkey(String inputText, By locator, String steps, int tiempo) throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {
				driver.findElement(locator).sendKeys(inputText);
				tiempoEspera(tiempo);
				captureScreen(steps);
				log.info("Se realiza un envio de texto en el elemento: {}", locator);
			} catch (Exception e) {
				captureScreenError(locator,
						"NO FUE POSIBLE LOCALIZAR EL ELEMENTO: (" + locator + ") PARA REALIZAR EL ENVÍO DEL TEXTO: "
								+ "\n" + "### ERROR COMPLETO: " + e.toString() + " ###");
				log.error(e.toString());
				throw new InterruptedException();
			}
		} else {
			try {
				driver.findElement(locator).sendKeys(inputText);
			} catch (Exception e) {
				printConsole(e.toString());
			}
		}
	}

	/**
	 * Espera hasta que el elemento seleccionado sea visible en la página web antes
	 * de continuar con la automatizacion.
	 *
	 * @param locator Localizador del elemento a interactuar.
	 * @param tiempo  Los segundos de espera antes de tomar la captura de la
	 *                evidencia.
	 */
	public static void visibilityOfElementLocated(By locator, int tiempo) {
		WebDriverWait espera = new WebDriverWait(driver, tiempo);
		espera.until(ExpectedConditions.visibilityOfElementLocated(locator));
		log.info("Se realiza la validación si es visible el elemento: {}", locator);
	}

	/**
	 * Cargar un archivo en una página web
	 *
	 * @param rutaArchivo La ruta al archivo que se desea cargar.
	 * @param locator     Localizador del elemento a interactuar.
	 * @param steps       Texto que se utilizará en la evidencia, para describir la
	 *                    accion realizada.
	 * @param tiempo      Los segundos de espera antes de tomar la captura de la
	 *                    evidencia.
	 * @throws Exception Si no se puede localizar el elemento, o si ocurre un error
	 *                   al generar la evidencia.
	 */
	public static void cargarArchivo(String rutaArchivo, By locator, String steps, int tiempo) throws Exception {
		// SE MANDA LA RUTA DONDE SE ENCUENTRE EL ARCHIVO
		File file = new File(rutaArchivo);
		// SE ESTRAE LA RUTA DEL SISTEMA
		String path = file.getPath();
		// SE ENVIA MEDIANTE UN SENDKEY (DEBE ENVIARSE A UN ELEMENTO "TYPE:FILE")
		sendkey(path, locator, steps, tiempo);
		log.info("Se carga archivo correctamente en: {}", locator);
	}

	/**
	 * Genera un nuevo localizador XPath a partir del localizador base, reemplazando
	 * el marcador de posición '{0}' con el valor a reemplazar.
	 *
	 * @param locatorBase     El localizador base utilizado para localizar el
	 *                        elemento deseado.
	 * @param valorDeRemplazo El valor que se utilizará para reemplazar el marcador
	 *                        de posición '{0}' en el localizador.
	 * @return Un nuevo localizador XPath con el valor de reemplazo aplicado.
	 * 
	 * @example Ejemplo1 El siguiente codigo muestra como usar el metodo
	 *          xpathInteractivo<br/>
	 *          // Ejemplo locatorBase // By locatorBase =
	 *          By.xpath("//input[@id='{0}']");
	 * 
	 *          // Valor para reemplazar en el locator // String valorAReemplazar =
	 *          "username";
	 * 
	 *          // Utilizar el método xpathInteractivo // By locatorPersonalizado =
	 *          xpathInteractivo(locatorBase, valorAReemplazar);
	 */
	public static By xpathInteractivo(By locatorBase, String valorDeRemplazo) {
		String jj = locatorBase.toString().replace("{0}", valorDeRemplazo);
		String kk = jj.replace("By.xpath:", "");
		return By.xpath(kk);
	}

	/**
	 * Verifica si el localizador está presente en la página web y toma una captura
	 * de pantalla si es necesario.
	 *
	 * @param locator Localizador del elemento a verificar.
	 * @param steps   Texto que se utilizará en la evidencia, para describir la
	 *                accion realizada.
	 * @param tiempo  El tiempo de espera antes de capturar la pantalla. *
	 * @return true si el localizador está presente en la página web, falso de lo
	 *         contrario.
	 * @throws InterruptedException Si la ejecución del hilo se interrumpe mientras
	 *                              se espera.
	 * @throws IOException          Si ocurre un error al guardar la captura de
	 *                              pantalla.
	 * @throws DocumentException    Si ocurre un error al crear el documento.
	 */
	public static boolean isPresent(By locator, String steps, int tiempo)
			throws InterruptedException, IOException, DocumentException {
		tiempoEspera(tiempo);
		isPresent = driver.findElements(locator).size() > 0;
		if (isPresent == true) {
			captureScreenSencillo(steps);
			log.info("el elemento esta presente: {}", locator);
			return true;
		} else {
			captureScreenSencillo(steps + "La validacion no es exitosa. El elemento " + locator + " no se encuentra");
			log.info("La validacion no es exitosa. El elemento " + locator + " no se encuentra");
			return false;
		}
	}

	/**
	 * Verifica si un elemento está habilitado y captura una pantalla si se cumple
	 * una condición.
	 *
	 * @param locator El localizador del elemento a verificar.
	 * @param steps   Una cadena de pasos que se utilizará para nombrar la captura
	 *                de pantalla en caso de error.
	 * @param tiempo  El tiempo de espera antes de capturar la pantalla.
	 * @return true si el elemento está habilitado, false en caso contrario.
	 * @throws Exception 
	 */
	public static boolean isEnabled(By locator, String steps, int tiempo) throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {
				// VERIFICAR SI ESTA HABILITADO UN LOCALIZADOR
				boolean enabled = driver.findElement(locator).isEnabled();
				tiempoEspera(tiempo);
				captureScreen(steps);
				log.info("El elemento se encuentra enabled: {}", locator);
				// RETORNA ENABLED
				return enabled;
			} catch (Exception e) {
				captureScreenError(locator,"NO FUE POSIBLE LOCALIZAR EL ELEMENTO: " + e.toString() + " ###");
				log.error(e.toString());
			}
			return false;
		} else {
			try {
				// VERIFICAR SI ESTA HABILITADO UN LOCALIZADOR
				boolean enabled = driver.findElement(locator).isEnabled();
				tiempoEspera(tiempo);
				return enabled;
			} catch (Exception e) {
				printConsole(e.toString());
			}
			return false;
		}
	}

	/**
	 * Verifica si el elemento identificado por el localizador está siendo mostrado
	 * en la página web, y toma una captura de pantalla si es necesario.
	 *
	 * @param locator          El localizador utilizado para identificar el elemento
	 *                         en la página web.
	 * @param steps            Una cadena de pasos que se utilizará para nombrar la
	 *                         captura de pantalla.
	 * @param tiempo           El tiempo de espera durante el fluente wait.
	 * @return true si el elemento está siendo mostrado, false si no lo está.
	 * @throws Exception Sí ocurre un error al realizar la verificación de
	 *                   visibilidad o al guardar la captura de pantalla.
	 */
	public static boolean isDisplayed(By locator, String steps, int tiempo) throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {
				boolean displayed = driver.findElement(locator).isDisplayed();
				tiempoEspera(tiempo);
				captureScreen(steps);
				return displayed;
			} catch (Exception e) {
				captureScreenError(locator, "LA VALIDACIÓN NO FUE COMPLETADA CORRECTAMENTE, EL ELEMENTO (" + locator
								+ ") NO SE ENCONTRÓ DESPLEGADO EN LA PAGINA: " + "\n" + "### ERROR COMPLETO: "
								+ e.toString() + " ###");
				log.error(e.toString());
				throw new InterruptedException();
			}
		} else {
			try {

				boolean displayed = driver.findElement(locator).isDisplayed();
				tiempoEspera(2);
				return displayed;
			} catch (Exception e) {
				printConsole(e.toString());
			}
			return false;
		}
	}

	/**
	 * Metodo encargado de simular un click en un formulario web cuando dicho
	 * elemento no es clicliable con el metodo Click, ya que este elemento se.
	 * encuentra oculto en el javaScrip.
	 * 
	 * @param locator          Localizador del elemento al que se enviara el
	 *                         formulario.
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @param tiempo           Los segundos de espera antes de tomar la captura de
	 *                         la evidencia.
	 * @throws Exception Si ocurre un error al realizar el submit o al guardar la
	 *                   captura de pantalla.
	 */
	public static void submit(By locator, String steps, int tiempo) throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {
				driver.findElement(locator).submit();
				tiempoEspera(tiempo);
				captureScreen(steps);
			} catch (Exception e) {
				captureScreenError(locator, "NO FUE POSIBLE LOCALIZAR EL ELEMENTO: (" + locator
						+ ") PARA REALIZAR EL SUBMIT: " + "\n" + "### ERROR COMPLETO: " + e.toString() + " ###");
				log.error(e.toString());
				throw new InterruptedException();
			}
		} else {
			try {
				driver.findElement(locator).submit();
				tiempoEspera(tiempo);
			} catch (Exception e) {
				printConsole(e.toString());
			}
		}
	}

	/**
	 * Realiza un scroll vertical en la página web y toma una captura de pantalla si
	 * es necesario.
	 *
	 * @param y             El número de píxeles que se desplazará la página web en
	 *                      cada movimiento.
	 * @param numMovimiento El número de movimientos que se realizarán.
	 * @param tiempo        Los segundos de espera antes de tomar la captura de la
	 *                      evidencia.
	 * @throws Exception Si ocurre un error al realizar el scroll o al guardar la
	 *                   captura de pantalla.
	 */
	public static void scrollWeb(int y, int numMovimiento, int tiempo) throws Exception {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			for (int i = 0; i <= numMovimiento; i++) {
				js.executeScript("window.scrollBy(0," + y + ")");
				tiempoEspera(tiempo);
			}
		} catch (Exception e) {
			log.error(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Realiza un scroll a un elemento denterminado dentro del from y toma una
	 * captura de pantalla si es necesario.
	 *
	 * @param locator          Localizador del elemento al que se enviara el
	 *                         formulario.
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @param tiempo           Los segundos de espera antes de tomar la captura de
	 *                         la evidencia.
	 * @throws Exception Si ocurre un error al realizar el scroll o al guardar la
	 *                   captura de pantalla.
	 */
	public static void scrollElement(By locator, String steps, int tiempo) throws Exception {
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			WebElement element = driver.findElement(locator);
			executor.executeScript("arguments[0].scrollIntoView();", element);
			captureScreen(steps);
			log.info("Se se realiza movimiento scroll sobre el elemento: {}", locator);
		} catch (Exception e) {
			captureScreenError(locator, "NO FUE POSIBLE LOCALIZAR EL ELEMENTO: (" + locator
					+ ") PARA REALIZAR EL SUBMIT: " + "\n" + "### ERROR COMPLETO: " + e.toString() + " ###");
			log.error(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Realiza un clic en el elemento seleccionado utilizando las coordenadas
	 * especificadas, y toma una captura de pantalla si es necesario.
	 *
	 * @param locator          Localizador del elemento al que se le realizara el
	 *                         clic.
	 * @param x                La coordenada "X" donde se realizará el clic relativo
	 *                         al elemento.
	 * @param y                La coordenada "Y" donde se realizará el clic relativo
	 *                         al elemento.
	 * @param steps            Una cadena de pasos que se utilizará para nombrar la
	 *                         captura de pantalla.
	 * @throws Exception si no se puede localizar el elemento, si ocurre un error al
	 *                   realizar el clic.
	 */
	public static void clickElementCoordenadas(By locator, int x, int y, String steps) throws Exception {
		int durationInMinutes = (1 * 1000);
		WebDriverWait wait = new WebDriverWait(driver, durationInMinutes);
		Actions builder = new Actions(driver);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		if (_generarEvidencia.equals("SI")) {
			try {
				captureScreen(steps);
				Action action = builder.moveToElement(element, x, y).click().build();
				action.perform();
				log.info("Se realiza click sobre el elemento: {}", locator);
			} catch (Exception e) {
				captureScreenError(locator, "NO FUE POSIBLE LOCALIZAR EL ELEMENTO: (" + locator + ") PARA REALIZAR EL ENVÍO DEL TEXTO: "
								+ "\n" + "### ERROR COMPLETO: " + e.toString() + " ###");
				log.error(e.toString());
				throw new InterruptedException();
			}
		} else {
			try {
				Action action = builder.moveToElement(element, x, y).click().build();
				action.perform();
			} catch (Exception e) {
				printConsole(e.toString());
			}
		}
	}

	/**
	 * Verifica si el elemento seleccionado es visible en la página web.
	 *
	 * @param locator El localizador utilizado para identificar el elemento en la
	 *                página web.
	 * @return True si el elemento está siendo mostrado, False si no lo está.
	 */
	public static boolean estadoElemento(By locator) {
	    return driver.findElement(locator).isDisplayed();
	}

	/**
	 * Obtiene el texto del elemento identificado por el localizador y toma una
	 * captura de pantalla si es necesario.
	 *
	 * @param locator          Localizador del elemento al que se le extraera el
	 *                         texto.
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @return El texto del elemento identificado por el localizador.
	 * @throws Exception Si ocurre un error al obtener el texto del elemento o al
	 *                   guardar la captura de pantalla.
	 */
	public static String capturarTexto(By locator, String steps) throws Exception {
		try {
			String resultado = driver.findElement(locator).getText();
			captureScreen(steps);
			log.info("Se realiza captura del texto sobre el elemento: {}", locator);
			return resultado;
		} catch (Exception e) {
			captureScreenError(locator, "NO FUE POSIBLE LOCALIZAR EL ELEMENTO: (" + locator
					+ ") PARA REALIZAR EL SUBMIT: " + "\n" + "### ERROR COMPLETO: " + e.toString() + " ###");
			log.error(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Espera a que un elemento sea visible durante un tiempo específico.
	 *
	 * @param locator El localizador del elemento a verificar.
	 * @param tiempo    El tiempo máximo a esperar en segundos.
	 * @return true si el elemento es visible dentro del tiempo especificado, false
	 *         en caso contrario.
	 */
	public static boolean validarElemento(By locator, int tiempo) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, tiempo);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Realiza la validación de dos valores booleanos y, en caso de error, toma una
	 * captura de pantalla y genera evidencia si está habilitado.
	 * 
	 * @param valor1           El primer valor booleano a validar.
	 * @param valor2           El segundo valor booleano a validar.
	 * @param idcaso           El nombre del caso de prueba o descripción de la
	 *                         validación.
	 * @throws IOException       Si ocurre un error de E/S al manipular archivos.
	 * @throws DocumentException Si ocurre un error durante la generación del
	 *                           reporte en formato PDF.
	 */
	public static void ValidacionObjetos(boolean valor1, boolean valor2, String idcaso)
			throws IOException, DocumentException {
		try {
			if (_generarEvidencia.equals("SI")) {
				if (valor1 == true && valor2 == true) {
					captureScreenSencillo("La validacion es exitosa  para el caso " + idcaso);
				} else {
					captureScreenSencillo("La validacion no es exitosa el elemento a validar no esta presente ");
				}
			} else if (valor1 == true && valor2 == true) {
				log.info("My Validacion exitosa");
			} else {
				log.info("My Validacion fallida");
			}
		} catch (Exception e) {
			captureScreenSencillo("ELEMENTO NO VALIDADO" + e);
		}
	}

	/**
	 * Toma una captura de pantalla, genera un reporte en formato PDF y devuelve la
	 * captura de pantalla como un arreglo de bytes, si la generación de evidencia
	 * está habilitada.
	 * 
	 * @param steps       Los pasos o descripción de la acción realizada.
	 * @return La captura de pantalla como un arreglo de bytes.
	 * @throws IOException       Si ocurre un error de E/S.
	 * @throws DocumentException Si ocurre un error durante la generación del
	 *                           reporte en formato PDF.
	 */
	public static byte[] captureScreenSencillo(String steps) throws IOException, DocumentException {
		String hora = tiempoSistema("HH-mm-ss");
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String rutaImagen = _rutaCarpeta + "\\" + hora + ".png";
		FileUtils.copyFile(scrFile, new File(rutaImagen));
		log.info("Se realiza camptura de imagen en al ruta: {}", rutaImagen);
		GenerarReportePdf.createBody(steps, rutaImagen);
		eliminarArchivo(rutaImagen);
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	}

	/**
	 * Toma una captura de pantalla del navegador y la guarda en el reporte pdf, si
	 * la evidencia esta habilitada.
	 *
	 * @param mensaje El mensaje asociado a la captura de pantalla.
	 * @throws IOException       Si ocurre un error de entrada/salida al guardar la
	 *                           captura de pantalla.
	 * @throws DocumentException Si ocurre un error al procesar un documento PDF.
	 */
	public static void captureScreen(String mensaje) throws IOException, DocumentException 
	{
		String hora = tiempoSistema("HH-mm-ss");
		WebDriver delegatedDriver = ((SelfHealingDriver) driver).getDelegate();
		File srcFile = ((TakesScreenshot) delegatedDriver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(srcFile, new File(_rutaCarpeta + "\\" + hora + ".png"));
		String rutaImagen = new File(_rutaCarpeta + "\\" + hora + ".png").toString();
		log.info("Se realiza camptura de imagen en al ruta: {}", rutaImagen);
		// INSTANCIAMOS LA CLASE GENERAR PDF
		GenerarReportePdf.createBody(mensaje, rutaImagen);
		// ELIMINAR IMAGEN CREADA
		eliminarArchivo(rutaImagen);

	}

	/**
	 * Captura una pantalla en caso de error y la guarda en el sistema de archivos.
	 *
	 * @param locator  El localizador del elemento relacionado con el error.
	 * @param msnError El mensaje de error asociado a la captura de pantalla.
	 * @throws Exception Si ocurre un error al capturar la pantalla o al guardarla
	 *                   en el sistema de archivos.
	 */
	public static void captureScreenError(By locator, String msnError) throws Exception {
		if (_generarEvidencia.equals("SI")) 
		{
			String hora = tiempoSistema("HH-mm-ss");
			WebDriver delegatedDriver = ((SelfHealingDriver) driver).getDelegate();
			File srcFile = ((TakesScreenshot) delegatedDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(srcFile, new File(_rutaCarpeta + "\\" + hora + ".png"));
			String rutaImagen = new File(_rutaCarpeta + "\\" + hora + ".png").toString();
			log.info("Se realiza camptura de imagen en al ruta: {}", rutaImagen);
			// SE PROCEDE A INSERTAR LOCALIZADOR HE IMAGEN EN EL PDF
			GenerarReportePdf.createErrorBody(locator, rutaImagen, msnError);
			// ELIMINAR IMAGEN CREADA
			eliminarArchivo(rutaImagen);
		}
	}

	/**
	 * Captura una pantalla en caso de error de ortografia y la guarda en el sistema
	 * de archivos.
	 *
	 * @param locator          El localizador del elemento relacionado con el error.
	 * @param msnError         El mensaje de error asociado a la captura de
	 *                         pantalla.
	 * @throws Exception Si ocurre un error al capturar la pantalla o al guardarla
	 *                   en el sistema de archivos.
	 */
	public static void captureScreenOrtografia(By locator, String msnError) throws Exception {
		if (_generarEvidencia.equals("SI"))
		{
			String hora = tiempoSistema("HH-mm-ss");
			WebDriver delegatedDriver = ((SelfHealingDriver) driver).getDelegate();
			File srcFile = ((TakesScreenshot) delegatedDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(srcFile, new File(_rutaCarpeta + "\\" + hora + ".png"));
			String rutaImagen = new File(_rutaCarpeta + "\\" + hora + ".png").toString();
			log.info("Se realiza camptura de imagen de error ortográfico en al ruta: {}", rutaImagen);
			// SE PROCEDE A INSERTAR LOCALIZADOR HE IMAGEN EN EL PDF
			GenerarReportePdf.createErrorOrtografia(locator, rutaImagen, msnError);
			// ELIMINAR IMAGEN CREADA
			eliminarArchivo(rutaImagen);
		}
	}

	/**
	 * Cambia de página en el navegador y toma una captura de pantalla, si la
	 * generación de evidencia está habilitada.
	 * 
	 * @param pagina           El número de la página a cambiar.
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @throws Exception Si ocurre un error durante la navegación, captura de
	 *                   pantalla o generación de reporte.
	 */
	public static void jumpPage(int pagina, String steps) throws Exception {
		driver.switchTo().defaultContent();
		driver.switchTo().window(driver.getWindowHandle());
		Object[] parentHandle = driver.getWindowHandles().toArray();
		driver.switchTo().window((String) parentHandle[pagina]);
		driver.manage().window().maximize();
		tiempoEspera(5);
		captureScreen(steps);
		log.info("Se realiza salto de pagina: {}", steps);
	}

	/**
	 * Realiza una aserción de igualdad entre dos variables y captura la pantalla.
	 *
	 * @param variable1        Primer valor a comparar.
	 * @param variable2        Segundo valor a comparar.
	 * @param steps            Una cadena de pasos que se utilizará para nombrar la
	 *                         captura de pantalla en caso de error.
	 * @return true si las variables son iguales, false en caso contrario.
	 * @throws Exception Si las variables no son iguales o si ocurre un error al
	 *                   capturar la pantalla.
	 */
	public static boolean AssertsEquals(String variable1, String variable2, String steps)
			throws Exception {
		try {
			assertEquals(variable1, variable2);
			captureScreen(steps);
			isPresent = true;
		} catch (Exception e) {
			GenerarReportePdf.closeTemplate(e.toString());
			log.error(e.toString());
			throw new InterruptedException();
		}
		return isPresent;
	}

	/**
	 * Genera un número aleatorio de la longitud especificada y lo envía al elemento
	 * especificado.
	 *
	 * @param elementLocation El locador para el elemento donde se desea ingresar el
	 *                        número aleatorio.
	 * @param num             La longitud del número aleatorio a generar.
	 * @throws Exception Si ocurre un error al generar el número aleatorio o al
	 *                   enviarlo al elemento.
	 */
	public static void escrinirNumRamdom(By locator, int num) {
		String acta = RandomStringUtils.randomNumeric(num);
		driver.findElement(locator).sendKeys(acta);
		log.info("Se escribe número ramdom sobre el elemento: {}", locator);
	}

	/**
	 * Genera un número aleatorio de la longitud especificada.
	 *
	 * @param num La longitud del número aleatorio a generar.
	 * @return El número aleatorio generado como una cadena de texto.
	 * @throws InterruptedException Si la ejecución del hilo se interrumpe mientras
	 *                              se espera.
	 */
	public static String randomNum(int num) {
		return RandomStringUtils.randomNumeric(num);		 
	}

	/**
	 * Cambia el contexto actual al iframe especificado.
	 *
	 * @param valor            El valor del atributo 'id' o 'name' del iframe al que
	 *                         se desea cambiar.
	 * @throws InterruptedException  Si la ejecución del hilo se interrumpe mientras
	 *                               se espera.
	 * @throws MalformedURLException Si ocurre un error al crear una URL mal
	 *                               formada.
	 * @throws DocumentException     Si ocurre un error al procesar un documento
	 *                               XML.
	 * @throws IOException           Si ocurre un error de entrada/salida.
	 */
	public static void MetodoIframe(String valor) throws InterruptedException {
		try {
			driver.switchTo().frame(valor);
		} catch (Exception e) {
			GenerarReportePdf.closeTemplate(e.toString());
			log.error(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Selecciona un archivo utilizando un campo de entrada de archivo en un
	 * formulario web, y toma una captura de pantalla si es necesario.
	 *
	 * @param locator          El localizador utilizado para identificar el campo de
	 *                         entrada de archivo en la página web.
	 * @param rutaArchivo      La ruta del archivo que se va a seleccionar.
	 * @param steps            Una cadena de pasos que se utilizará para nombrar la
	 *                         captura de pantalla.
	 * @param tiempo           El tiempo de espera después de seleccionar el
	 *                         archivo.
	 * @throws Exception Si ocurre un error al seleccionar el archivo o al guardar
	 *                   la captura de pantalla.
	 */
	public static void selecionarArchivoCss(By locator, String rutaArchivo, String steps,int tiempo) throws Exception 
	{
		try {
			WebElement fileInput = driver.findElement(locator);
			fileInput.sendKeys(rutaArchivo);
			tiempoEspera(tiempo);
			captureScreen(steps);
			log.info("Selecciona archivo: {}", rutaArchivo);
		} catch (Exception e) {
			captureScreenError(locator, e.toString());
			log.error(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Compara un conjunto de líneas de un archivo PDF con un texto dado y devuelve
	 * true si se encuentra el texto en al menos una línea del archivo.
	 *
	 * @param file  Un objeto ArrayList que contiene las líneas del archivo PDF.
	 * @param texto El texto a buscar en el archivo PDF.
	 * @return true si el texto se encuentra en al menos una línea del archivo PDF,
	 *         false en caso contrario.
	 */
	public static boolean compararValorPDF(ArrayList<String> file, String texto) throws IOException {
		boolean ok = false;
		// RECORRE LAS LINEAS DEL ARCHIVO
		for (String linea : file) {
			if (linea.contains(texto)) {
				ok = true;
				break;
			}
		}
		return ok;
	}

	/**
	 * Metodo encargado de resolver reCaptcha
	 * 
	 * @param apikey           Se obtiene de la cuenta creada de 2captcha.
	 * @param sitekey          Identificador unico del captcha obtenido del DOM de
	 *                         la pagina.
	 * @param seturl           Pagina principal donde se encuentra el captcha.
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @param tiempo           El tiempo de espera después de seleccionar el
	 *                         archivo.
	 * @throws InterruptedException Si ocurre un error al capturar la pantalla o al
	 *                              guardarla en el sistema de archivos.
	 */

	public static void resolverCaptcha(String apikey, String sitekey, String seturl, String steps, int tiempo) throws InterruptedException 
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {

			// Resolver el Captcha
			System.out.println("Solving Captcha");
			TwoCaptcha solver = new TwoCaptcha(apikey);
			ReCaptcha captcha = new ReCaptcha();

			captcha.setSiteKey(sitekey);
			captcha.setUrl(seturl);

			solver.solve(captcha);
			String code = captcha.getCode();
			System.out.println("Successfully solved the Captcha. The solve code is " + code);

			WebElement recaptchaResponseElement = driver.findElement(By.id("g-recaptcha-response"));
			js.executeScript("arguments[0].value='" + code + "';", recaptchaResponseElement);

			tiempoEspera(tiempo);
			captureScreen(steps);
			log.info("Se realiza accion capchat");
		} catch (Exception e) {
			log.error(e.toString());
			GenerarReportePdf.closeTemplate(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Metodo encargado de simular el moviemiento del mause sobre un elemento de la
	 * pagina web
	 * 
	 * @param locator          El localizador utilizado para identificar el campo de
	 *                         entrada de archivo en la página web.
	 * @param steps            Una cadena de pasos que se utilizará para nombrar la
	 *                         captura de pantalla.
	 * @param tiempo           El tiempo de espera después de seleccionar el
	 *                         archivo.
	 * @throws Exception Si ocurre un error al seleccionar el archivo o al guardar
	 *                   la captura de pantalla.
	 */

	public static void hover(By locator, String steps, int tiempo) throws Exception {

		try {
			WebElement element = driver.findElement(locator);
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();
			captureScreen(steps);
			log.info("Se realiza accion hover sobre el elemento: {}", locator);
		} catch (Exception e) {
			captureScreenError(locator, e.toString());
			log.error(e.toString());
			throw new InterruptedException();
		}
	}

	/**
	 * Simula la presión de las teclas "Tab" y luego "Enter".
	 *
	 * @throws InterruptedException Si la ejecución del hilo se interrumpe mientras
	 *                              se espera.
	 */
	public static void tabEnter() throws InterruptedException {
		Actions action = new Actions(driver);
		action.sendKeys(Keys.TAB).build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
		tiempoEspera(2);
	}

	/**
	 * Simula la presión de la tecla "Tab" un número específico de veces.
	 *
	 * @param valor El número de veces que se simulará la presión de la tecla "Tab".
	 * @throws InterruptedException Si la ejecución del hilo se interrumpe mientras
	 *                              se espera.
	 */
	public static void tabulacion(int valor) {
		Actions action = new Actions(driver);
		for (int i = 0; i < valor; i++) {
			action.sendKeys(Keys.TAB).build().perform();
		}
	}

	/**
	 * Simula la pulsación de la tecla "Enter"
	 *
	 * @throws InterruptedException
	 */
	public static void enter() throws InterruptedException {
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ENTER).build().perform();
		tiempoEspera(3);
	}

	/**
	 * Simula la pulsación de la tecla "Escape"
	 *
	 * @throws InterruptedException Se interrumpe el proceso
	 */
	public static void escape() throws InterruptedException {
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ESCAPE).build().perform();
		tiempoEspera(2);
	}

	private interface Hunspell extends Library {
		Hunspell INSTANCE = (Hunspell) Native.load("D:/Directorio/libhunspell.dll", Hunspell.class);

		Pointer Hunspell_create(String affpath, String dicpath);

		void Hunspell_destroy(Pointer handle);

		int Hunspell_spell(Pointer handle, String word);
	}

	/**
	 * Obtiene el texto del elemento identificado por el localizador y toma una
	 * captura de pantalla si es necesario.
	 *
	 * @param locator Localizador del elemento al que se le extraera el texto.
	 * @return El texto del elemento seleccionado.
	 */
	public static String textoValidacionSinEvidencia(By locator) {
		return driver.findElement(locator).getText();
	}

	/**
	 * Metodo encargado de validar elementos ortografivos en la web
	 * 
	 * @param locator          El localizador utilizado para identificar el campo de
	 *                         entrada de archivo en la página web.
	 * @param folderPath       La ruta de la carpeta donde se guardará la captura de
	 *                         pantalla.
	 * @param generarEvidencia Una cadena que indica si se debe generar evidencia o
	 *                         no.
	 * @throws Exception Si ocurre un error al capturar la pantalla o al guardarla
	 *                   en el sistema de archivos.
	 */
	public static void ortografiaWeb(By locator, File folderPath, String generarEvidencia) throws Exception {
		String dictionaryPath = "D:/Directorio/es_ES.dic";
		String affixPath = "D:/Directorio/es_ES.aff";
		String parrafo = Periferia.textoValidacionSinEvidencia(locator);

		Pointer handle = Hunspell.INSTANCE.Hunspell_create(affixPath, dictionaryPath);
		if (handle != null) {
			// String paragraph = "Este es un ejemplo de un páorrafo con algunas palabras
			// mal escritas.";
			String[] words = parrafo.split("\\s+");
			for (String word : words) {
				String ss = word.replaceAll(",", "");
				if (Hunspell.INSTANCE.Hunspell_spell(handle, ss) == 0) {
					captureScreenOrtografia(locator, generarEvidencia);
					tiempoEspera(2);
				}
			}
			Hunspell.INSTANCE.Hunspell_destroy(handle);
		} else {
			System.err.println("No se pudo crear el handle de Hunspell.");
		}
	}

	/**
	 * Metodo encargado de validar palabras ortografivos de un texto
	 * 
	 * @param texto cadena de palabras a validar tipo String
	 * @throws Exception Si ocurre un error al capturar la pantalla o al guardarla
	 *                   en el sistema de archivos.
	 */
	public static void ortografiaTexto(String texto) throws Exception {
		String dictionaryPath = "D:/Directorio/es_ES.dic";
		String affixPath = "D:/Directorio/es_ES.aff";

		Pointer handle = Hunspell.INSTANCE.Hunspell_create(affixPath, dictionaryPath);
		if (handle != null) {
			// String paragraph = "Este es un ejemplo de un páorrafo con algunas palabras
			// mal escritas.";
			String[] words = texto.split("\\s+");
			for (String word : words) {
				String ss = word.replaceAll(",", "");
				if (Hunspell.INSTANCE.Hunspell_spell(handle, ss) == 0) {
					String error = ("La palabra \"" + ss + "\" está mal escrita.");
					GenerarReportePdf.createErrorOrtografiaString(error);
					tiempoEspera(2);
				}
			}
			Hunspell.INSTANCE.Hunspell_destroy(handle);
		} else {
			System.err.println("No se pudo crear el handle de Hunspell.");
		}
	}

	/**
	 * Imprime un mensaje en consola.
	 *
	 * @param texto Mensaje a mostrar en consola.
	 */
	public static void printConsole(String texto) {
		System.out.println(texto);
	}

	/**
	 * Actualiza la página web y luego espera tres segundos antes de continuar.
	 *
	 * @throws InterruptedException Si ocurre un error al refrescar la página.
	 */
	public static void refrescarPagina() throws InterruptedException {
		driver.navigate().refresh();
		tiempoEspera(3);
	}

	/**
	 * Suspende la ejecución del hilo actual durante el tiempo en segundos
	 * proporcionado.
	 *
	 * @param tiempo El tiempo a esperar en segundos.
	 * @throws InterruptedException Si ocurre un error al esperar.
	 */
	public static void tiempoEspera(long tiempo) throws InterruptedException {
		Thread.sleep(tiempo * 1000);
	}

	/**
	 * Crea una carpeta en la ruta especificada si la evidencia está habilitada.
	 * 
	 * @param nomTest          El nombre del test en ejecución.
	 * @return El directorio de la carpeta creada.
	 * @throws IOException Si ocurre un error de Entrada/Salida.
	 */
	public static File crearCarpeta(String nomTest) throws IOException {
		File directorio = null;
		if (_generarEvidencia.equals("SI")) {
			// ALMACENAMOS LA FECHA DEL SISTEMA
			String fecha = tiempoSistema("yyyyMMdd-HHmmss");
			// CREAMOS EL NOMBRE DE LA CARPETA
			String nomCarpeta = nomTest + "-" + fecha;
			// OBTENEMOS LA RETA DE ALOJAMIENTO DE SALIDA Y EL NOMBRE DEL TEST A EJECUTAR
			directorio = new File(_rutaCarpeta + nomCarpeta);
			// CREAMOS LA CARPETA
			directorio.mkdir();
		}
		return directorio;
	}

	/**
	 * Elimina un directorio y su contenido.
	 *
	 * @param directory El directorio que se eliminará.
	 * @throws IOException Sí ocurre un error de entrada/salida al eliminar el
	 *                     directorio y su contenido.
	 */
	public static void deleteDirectory(File directory) throws IOException, IOException {
		if (directory.exists()) {
			Files.walk(directory.toPath()).sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
		}
	}

	/**
	 * Elimina una carpeta en la ruta especificada si existe.
	 * 
	 * @param ruta La ruta de la carpeta a eliminar.
	 * @throws IOException Si ocurre un error de E/S.
	 */
	public static void eliminarCarpeta() throws IOException {
		File directory = new File(_rutaCarpeta);
		if (directory.exists()) {
			for (File file : Objects.requireNonNull(directory.listFiles())) {
				if (file.isDirectory()) {
					deleteDirectory(file);
				} else {
					file.delete();
				}
			}
		}
	}

	/**
	 * Elimina un archivo en la ruta especificada.
	 * 
	 * @param rutaImagen La ruta del archivo a eliminar.
	 * @throws IOException Si ocurre un error de E/S.
	 */
	public static void eliminarArchivo(String rutaImagen) {
		File fichero = new File(rutaImagen);
		fichero.delete();
	}

	/**
	 * Mueve un archivo de una carpeta a otra, teniendo en cuenta solo archivos y no
	 * carpetas.
	 *
	 * @param rutaOrigen  La ruta de la carpeta de origen.
	 * @param rutaDestino La ruta de la carpeta de destino.
	 * @return La ruta del archivo copiado en la carpeta de destino, o null si no se
	 *         encontraron archivos en la carpeta origen.
	 */
	public static String moverCarpeta(String rutaOrigen, String rutaDestino) {
		File archivoMasReciente = null;
		long ultimaModificacion = Long.MIN_VALUE;
		// CONVERCION DE RUTAS TIPO STRING A TIPO FILE
		File direcrioOrigren = new File(rutaOrigen);
		File directorioDestino = new File(rutaDestino);
		// CAPTURA DE ARCHIVOS RUTA ORIGEN
		File[] archivos = direcrioOrigren.listFiles();
		// OBTIENE EL ULTIMO ARCHIVO RECIENTE DE RUTA ORIGEN
		for (File archivo : archivos) {
			// VERIFICA QUE SEAN SOLO ARCHIVOS Y NO CARPETAS Y VALIDA QUE SEA LA ULTIMA
			if (archivo.isFile() && archivo.lastModified() > ultimaModificacion) {
				archivoMasReciente = archivo;
				ultimaModificacion = archivo.lastModified();
			}
		}
		// VALIDA QUE EL ARCHIVO MAS RECIENTE NO ESTE VACIO
		if (archivoMasReciente != null) {
			// CONSTRUYE LA RUTA DEL ARCHIVO EN EL DIRECTORIO DESRTINO
			File destinoArchivo = new File(directorioDestino, archivoMasReciente.getName());
			try {
				// COPIA EL ARCHIVO MAS RECIENTE A LA CARPETA DE DESTINO
				FileUtils.copyFile(archivoMasReciente, destinoArchivo);
				System.out.println("Archivo copiado: " + destinoArchivo.getAbsolutePath());
				return destinoArchivo.getAbsolutePath();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("No se encontraron archivos en la carpeta origen.");
		}
		return null;
	}

	/**
	 * Obtiene la hora actual del sistema en el formato especificado y la devuelve
	 * como una cadena de texto.
	 * 
	 * @param formatter El formato de la hora deseado (por ejemplo, "HH:mm:ss").
	 * @return La hora actual del sistema en el formato especificado.
	 * 
	 * @example ejemplo1 La siguiente línea muestra cómo usar el método con el
	 *          formato "HH:mm:ss":<br/>
	 *          // String fecha = tiempoSistema("HH:mm:ss");
	 * 
	 * @example ejemplo2 La siguiente línea muestra cómo usar el método con el
	 *          formato "yyyy-MM-dd HH:mm:ss":<br/>
	 *          // String formato = "yyyy-MM-dd HH:mm:ss" // String fecha =
	 *          tiempoSistema(formato);
	 */
	public static String tiempoSistema(String formatter) {
		// TOMAMOS LA FECHA DEL SISTEMA
		LocalDateTime fechaSistema = LocalDateTime.now();
		// DEFINIR FORMATO FECHA
		DateTimeFormatter fecha = DateTimeFormatter.ofPattern(formatter);
		// DAR FORMATO A LA FECHA DEL SISTEMA
		String formatFecha = fecha.format(fechaSistema);
		return formatFecha;
	}

	/**
	 * Metodo encargado de capturar la imagen de un elemento en la página.
	 * 
	 * @param locator          Localizador del elemento que se desea capturar, se
	 *                         espera que sea un elemento visible en el DOM.
	 * @param imagenQR         La ruta donde se almacena el Codigo QR
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @param tiempo           Los segundos de espera antes de tomar la captura de
	 *                         la evidencia.
	 * 
	 * 
	 * @throws Exception
	 */
	public static void capturaImagenQr(By locator, String imagenQR, String steps, int tiempo)
			throws Exception {
		if (_generarEvidencia.equals("SI")) {
			try {

				// Encuentra el elemento de la imagen del captcha usando la clase
				WebElement captchaImg = driver.findElement(locator);

				// Toma una captura de pantalla del elemento
				File screenshot = captchaImg.getScreenshotAs(OutputType.FILE);

				// Guarda la captura de pantalla en el disco
				FileHandler.copy(screenshot, new File(imagenQR));

				captureScreen(steps);
				log.info("Se captura codigo QR: " + locator);

			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				// Encuentra el elemento de la imagen del captcha usando la clase
				WebElement captchaImg = driver.findElement(locator);

				// Toma una captura de pantalla del elemento
				File screenshot = captchaImg.getScreenshotAs(OutputType.FILE);

				// Guarda la captura de pantalla en el disco
				FileHandler.copy(screenshot, new File(imagenQR));
				tiempoEspera(tiempo);
			} catch (Exception e) {
				captureScreenError(locator, e.toString());
				log.error(e.toString());
				throw new InterruptedException();
			}
		}
	}

	/**
	 * Metodo encargado de resolver un código QR a partir de una imagen PNG.
	 * 
	 * @param imagenQR         La ruta donde se almacena el Codigo QR
	 * @param steps            Texto que se utilizará en la evidencia, para
	 *                         describir la accion realizada.
	 * @param tiempo           Los segundos de espera antes de tomar la captura de
	 *                         la evidencia.
	 * @throws InterruptedException Si ocurre un error durante la lectura de la
	 *                              imagen o el proceso de decodificación.
	 * @throws IOException          Si ocurre un error al cargar la imagen desde el
	 *                              sistema de archivos.
	 * @throws DocumentException
	 * @throws NotFoundException
	 */
	public static void resolverQr(String imagenQR, String steps, int tiempo)
			throws InterruptedException, IOException, DocumentException, NotFoundException {

		Result result = null;
		// Cargar la imagen QR desde un archivo PNG
		File file = new File(imagenQR);
		BufferedImage bufferedImage = ImageIO.read(file);
		// Crear un objeto BinaryBitmap a partir de la imagen cargada
		BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(bufferedImage)));
		// Leer el código QR utilizando ZXing
		result = new MultiFormatReader().decode(bitmap);
		tiempoEspera(tiempo);
		driver.get(result.getText());
		if (_generarEvidencia.equals("SI")) {
			try {
				captureScreen(steps);
				log.info("Se resuleve codigo QR: ");
			} catch (IOException e) {
				System.err.println("Error al cargar la imagen: " + e.getMessage());
			}
		}
	}
}
